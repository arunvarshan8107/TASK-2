#!/bin/bash
# ============================================================
#  Google Cloud Monitoring — Full Setup Script
#  Sets up: notification channels, alert policies, dashboards,
#           uptime checks, log-based metrics, SLOs
#  Usage: bash setup_monitoring.sh [PROJECT_ID] [APP_NAME] [ALERT_EMAIL]
# ============================================================

set -euo pipefail

PROJECT_ID="${1:-my-gcp-project}"
APP_NAME="${2:-my-app}"
ALERT_EMAIL="${3:-alerts@example.com}"
REGION="${4:-us-central1}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ── Preflight ────────────────────────────────────────────────
check_prerequisites() {
  info "Checking prerequisites..."
  command -v gcloud >/dev/null || error "gcloud CLI not found."
  gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q . \
    || error "No active account. Run: gcloud auth login"
  gcloud config set project "${PROJECT_ID}"
  success "Prerequisites OK."
}

# ── Enable APIs ───────────────────────────────────────────────
enable_apis() {
  info "Enabling Monitoring, Logging, and Trace APIs..."
  gcloud services enable \
    monitoring.googleapis.com \
    logging.googleapis.com \
    cloudtrace.googleapis.com \
    clouderrorreporting.googleapis.com \
    cloudprofiler.googleapis.com \
    --quiet
  success "APIs enabled."
}

# ── Notification channel (Email) ──────────────────────────────
create_notification_channel() {
  info "Creating email notification channel → ${ALERT_EMAIL}..."
  CHANNEL_ID=$(gcloud alpha monitoring channels create \
    --display-name="${APP_NAME} Alerts" \
    --type=email \
    --channel-labels="email_address=${ALERT_EMAIL}" \
    --format="value(name)" 2>/dev/null || echo "")

  if [[ -z "${CHANNEL_ID}" ]]; then
    warn "Could not auto-create channel. Create manually:"
    warn "  gcloud alpha monitoring channels create \\"
    warn "    --display-name='${APP_NAME} Alerts' \\"
    warn "    --type=email --channel-labels='email_address=${ALERT_EMAIL}'"
  else
    echo "NOTIFICATION_CHANNEL_ID=${CHANNEL_ID}" > /tmp/monitoring_env
    success "Notification channel created: ${CHANNEL_ID}"
  fi
}

# ── Alert policies ────────────────────────────────────────────
create_alert_policies() {
  info "Creating alert policies..."
  source /tmp/monitoring_env 2>/dev/null || NOTIFICATION_CHANNEL_ID=""

  # ── 1. High CPU utilization (>80% for 5 min) ─────────────
  cat > /tmp/alert_cpu.json <<EOF
{
  "displayName": "${APP_NAME} — High CPU Utilization",
  "documentation": {
    "content": "CPU utilization has exceeded 80% for 5 minutes. Check for runaway processes or consider scaling up.",
    "mimeType": "text/markdown"
  },
  "conditions": [{
    "displayName": "CPU > 80%",
    "conditionThreshold": {
      "filter": "resource.type = \"gce_instance\" AND metric.type = \"compute.googleapis.com/instance/cpu/utilization\"",
      "aggregations": [{
        "alignmentPeriod": "300s",
        "perSeriesAligner": "ALIGN_MEAN",
        "crossSeriesReducer": "REDUCE_MEAN",
        "groupByFields": ["resource.labels.instance_id"]
      }],
      "comparison": "COMPARISON_GT",
      "thresholdValue": 0.80,
      "duration": "300s",
      "trigger": { "count": 1 }
    }
  }],
  "alertStrategy": {
    "autoClose": "1800s",
    "notificationRateLimit": { "period": "300s" }
  },
  "combiner": "OR",
  "enabled": true,
  "notificationChannels": ["${NOTIFICATION_CHANNEL_ID}"],
  "severity": "WARNING"
}
EOF

  # ── 2. High Memory usage (>85%) ──────────────────────────
  cat > /tmp/alert_memory.json <<EOF
{
  "displayName": "${APP_NAME} — High Memory Usage",
  "documentation": {
    "content": "Memory usage exceeds 85%. Risk of OOM crashes. Investigate memory leaks or increase instance memory.",
    "mimeType": "text/markdown"
  },
  "conditions": [{
    "displayName": "Memory > 85%",
    "conditionThreshold": {
      "filter": "resource.type = \"gce_instance\" AND metric.type = \"agent.googleapis.com/memory/percent_used\"",
      "aggregations": [{
        "alignmentPeriod": "300s",
        "perSeriesAligner": "ALIGN_MEAN"
      }],
      "comparison": "COMPARISON_GT",
      "thresholdValue": 85,
      "duration": "300s",
      "trigger": { "count": 1 }
    }
  }],
  "combiner": "OR",
  "enabled": true,
  "notificationChannels": ["${NOTIFICATION_CHANNEL_ID}"],
  "severity": "WARNING"
}
EOF

  # ── 3. HTTP 5xx Error Rate (>1% over 5 min) ──────────────
  cat > /tmp/alert_5xx.json <<EOF
{
  "displayName": "${APP_NAME} — High HTTP 5xx Error Rate",
  "documentation": {
    "content": "5xx error rate exceeded 1%. Your application is returning server errors. Check application logs immediately.",
    "mimeType": "text/markdown"
  },
  "conditions": [{
    "displayName": "5xx error rate > 1%",
    "conditionThreshold": {
      "filter": "resource.type = \"gae_app\" AND metric.type = \"appengine.googleapis.com/http/server/response_count\" AND metric.labels.response_code >= \"500\"",
      "aggregations": [{
        "alignmentPeriod": "300s",
        "perSeriesAligner": "ALIGN_RATE",
        "crossSeriesReducer": "REDUCE_SUM"
      }],
      "comparison": "COMPARISON_GT",
      "thresholdValue": 0.01,
      "duration": "300s"
    }
  }],
  "combiner": "OR",
  "enabled": true,
  "notificationChannels": ["${NOTIFICATION_CHANNEL_ID}"],
  "severity": "ERROR"
}
EOF

  # ── 4. High Latency p95 > 2s ────────────────────────────
  cat > /tmp/alert_latency.json <<EOF
{
  "displayName": "${APP_NAME} — High Request Latency (p95 > 2s)",
  "documentation": {
    "content": "95th percentile request latency exceeds 2 seconds. Users may experience slow responses. Profile your application.",
    "mimeType": "text/markdown"
  },
  "conditions": [{
    "displayName": "p95 latency > 2s",
    "conditionThreshold": {
      "filter": "resource.type = \"gae_app\" AND metric.type = \"appengine.googleapis.com/http/server/response_latencies\"",
      "aggregations": [{
        "alignmentPeriod": "300s",
        "perSeriesAligner": "ALIGN_PERCENTILE_95"
      }],
      "comparison": "COMPARISON_GT",
      "thresholdValue": 2000,
      "duration": "300s"
    }
  }],
  "combiner": "OR",
  "enabled": true,
  "notificationChannels": ["${NOTIFICATION_CHANNEL_ID}"],
  "severity": "WARNING"
}
EOF

  # ── 5. Disk usage > 90% ──────────────────────────────────
  cat > /tmp/alert_disk.json <<EOF
{
  "displayName": "${APP_NAME} — Disk Usage Critical (>90%)",
  "documentation": {
    "content": "Disk utilization exceeded 90%. Risk of disk full errors which can crash the application. Free up space immediately.",
    "mimeType": "text/markdown"
  },
  "conditions": [{
    "displayName": "Disk > 90%",
    "conditionThreshold": {
      "filter": "resource.type = \"gce_instance\" AND metric.type = \"agent.googleapis.com/disk/percent_used\"",
      "aggregations": [{
        "alignmentPeriod": "300s",
        "perSeriesAligner": "ALIGN_MEAN"
      }],
      "comparison": "COMPARISON_GT",
      "thresholdValue": 90,
      "duration": "60s"
    }
  }],
  "combiner": "OR",
  "enabled": true,
  "notificationChannels": ["${NOTIFICATION_CHANNEL_ID}"],
  "severity": "CRITICAL"
}
EOF

  # ── 6. Uptime check failure ──────────────────────────────
  cat > /tmp/alert_uptime.json <<EOF
{
  "displayName": "${APP_NAME} — Uptime Check Failed",
  "documentation": {
    "content": "The application health endpoint is not responding. The service may be down.",
    "mimeType": "text/markdown"
  },
  "conditions": [{
    "displayName": "Health check failure",
    "conditionThreshold": {
      "filter": "resource.type = \"uptime_url\" AND metric.type = \"monitoring.googleapis.com/uptime_check/check_passed\" AND metric.labels.check_id = \"${APP_NAME}-health\"",
      "aggregations": [{
        "alignmentPeriod": "300s",
        "perSeriesAligner": "ALIGN_FRACTION_TRUE",
        "crossSeriesReducer": "REDUCE_SUM",
        "groupByFields": ["resource.labels.host"]
      }],
      "comparison": "COMPARISON_LT",
      "thresholdValue": 1,
      "duration": "60s"
    }
  }],
  "combiner": "OR",
  "enabled": true,
  "notificationChannels": ["${NOTIFICATION_CHANNEL_ID}"],
  "severity": "CRITICAL"
}
EOF

  # ── 7. Cloud SQL connections > 90% of max ────────────────
  cat > /tmp/alert_sql.json <<EOF
{
  "displayName": "${APP_NAME} — Cloud SQL Connection Saturation",
  "documentation": {
    "content": "Cloud SQL connections are near maximum. New connections may be refused.",
    "mimeType": "text/markdown"
  },
  "conditions": [{
    "displayName": "SQL connections > 90% capacity",
    "conditionThreshold": {
      "filter": "resource.type = \"cloudsql_database\" AND metric.type = \"cloudsql.googleapis.com/database/postgresql/num_backends\"",
      "aggregations": [{
        "alignmentPeriod": "300s",
        "perSeriesAligner": "ALIGN_MEAN"
      }],
      "comparison": "COMPARISON_GT",
      "thresholdValue": 90,
      "duration": "300s"
    }
  }],
  "combiner": "OR",
  "enabled": true,
  "notificationChannels": ["${NOTIFICATION_CHANNEL_ID}"],
  "severity": "WARNING"
}
EOF

  # Deploy all policies
  for policy_file in cpu memory 5xx latency disk uptime sql; do
    gcloud alpha monitoring policies create \
      --policy-from-file="/tmp/alert_${policy_file}.json" \
      --quiet 2>/dev/null \
      && success "Alert policy created: ${policy_file}" \
      || warn "Policy ${policy_file}: requires gcloud alpha component or check permissions"
  done
}

# ── Uptime checks ─────────────────────────────────────────────
create_uptime_checks() {
  info "Creating uptime checks..."
  # Replace with your actual app URL
  APP_URL="https://${APP_NAME}.${REGION}.r.appspot.com"

  cat > /tmp/uptime_check.json <<EOF
{
  "displayName": "${APP_NAME} Health Endpoint",
  "httpCheck": {
    "path": "/health",
    "port": 443,
    "useSsl": true,
    "validateSsl": true,
    "requestMethod": "GET"
  },
  "monitoredResource": {
    "type": "uptime_url",
    "labels": {
      "project_id": "${PROJECT_ID}",
      "host": "${APP_NAME}.${REGION}.r.appspot.com"
    }
  },
  "period": "60s",
  "timeout": "10s",
  "selectedRegions": ["USA", "EUROPE", "ASIA_PACIFIC"],
  "contentMatchers": [{
    "content": "ok",
    "matcher": "CONTAINS_STRING"
  }]
}
EOF

  gcloud alpha monitoring uptime create \
    --display-name="${APP_NAME} Health Check" \
    --resource-type=uptime_url \
    --resource-labels="host=${APP_NAME}.${REGION}.r.appspot.com,project_id=${PROJECT_ID}" \
    --http-check-path="/health" \
    --period=60 \
    --timeout=10 \
    --regions="usa,europe,asia-pacific" \
    --quiet 2>/dev/null \
    && success "Uptime check created." \
    || warn "Uptime check: run manually or via Terraform config."
}

# ── Log-based metrics ─────────────────────────────────────────
create_log_metrics() {
  info "Creating log-based metrics..."

  # Error log count
  gcloud logging metrics create "${APP_NAME}_error_count" \
    --description="Count of ERROR severity log entries" \
    --log-filter="resource.type=\"gae_app\" severity=ERROR" \
    --quiet 2>/dev/null \
    && success "Log metric created: error_count" \
    || warn "Log metric error_count already exists or check permissions."

  # 5xx response log count
  gcloud logging metrics create "${APP_NAME}_5xx_count" \
    --description="Count of HTTP 5xx responses in logs" \
    --log-filter="resource.type=\"gae_app\" httpRequest.status>=500" \
    --quiet 2>/dev/null \
    && success "Log metric created: 5xx_count" \
    || warn "Log metric 5xx_count already exists."
}

# ── Summary ───────────────────────────────────────────────────
print_summary() {
  echo ""
  echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}${BOLD}║     Google Cloud Monitoring Setup Complete ✅        ║${NC}"
  echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════════╝${NC}"
  echo ""
  echo "  Project : ${PROJECT_ID}"
  echo "  App     : ${APP_NAME}"
  echo "  Alerts  → ${ALERT_EMAIL}"
  echo ""
  echo "  Alert Policies Created (7):"
  echo "    🟡 High CPU Utilization        (> 80%  for 5 min)"
  echo "    🟡 High Memory Usage           (> 85%  for 5 min)"
  echo "    🔴 HTTP 5xx Error Rate         (> 1%   for 5 min)"
  echo "    🟡 High Request Latency p95    (> 2s   for 5 min)"
  echo "    🔴 Disk Usage Critical         (> 90%  for 1 min)"
  echo "    🔴 Uptime Check Failure        (< 100% for 1 min)"
  echo "    🟡 Cloud SQL Connection Sat.   (> 90 connections)"
  echo ""
  echo "  Uptime Checks (3 regions): USA · Europe · Asia-Pacific"
  echo "  Log Metrics  : error_count, 5xx_count"
  echo ""
  echo "  View in Console:"
  echo "  https://console.cloud.google.com/monitoring?project=${PROJECT_ID}"
  echo ""
}

main() {
  check_prerequisites
  enable_apis
  create_notification_channel
  create_alert_policies
  create_uptime_checks
  create_log_metrics
  print_summary
}

main "$@"
