# ============================================================
#  Terraform — Google Cloud Monitoring Full Stack
#  Includes: notification channels, 7 alert policies,
#            dashboard, uptime checks, log-based metrics, SLO
# ============================================================

terraform {
  required_version = ">= 1.5"
  required_providers {
    google = { source = "hashicorp/google", version = "~> 5.0" }
  }
}

variable "project_id"   { type = string }
variable "app_name"     { type = string, default = "my-app" }
variable "alert_email"  { type = string }
variable "app_url"      { type = string, default = "https://my-app.example.com" }
variable "region"       { type = string, default = "us-central1" }

provider "google" {
  project = var.project_id
  region  = var.region
}

# ── APIs ──────────────────────────────────────────────────────
resource "google_project_service" "monitoring" {
  service = "monitoring.googleapis.com"
}
resource "google_project_service" "logging" {
  service = "logging.googleapis.com"
}
resource "google_project_service" "cloudtrace" {
  service = "cloudtrace.googleapis.com"
}
resource "google_project_service" "errorreporting" {
  service = "clouderrorreporting.googleapis.com"
}

# ── Notification Channel — Email ──────────────────────────────
resource "google_monitoring_notification_channel" "email" {
  display_name = "${var.app_name} Email Alerts"
  type         = "email"
  labels       = { email_address = var.alert_email }
  depends_on   = [google_project_service.monitoring]
}

# ── Uptime Check ──────────────────────────────────────────────
resource "google_monitoring_uptime_check_config" "health" {
  display_name = "${var.app_name} Health Check"
  timeout      = "10s"
  period       = "60s"

  http_check {
    path         = "/health"
    port         = "443"
    use_ssl      = true
    validate_ssl = true
    request_method = "GET"
    accepted_response_status_codes {
      status_class = "STATUS_CLASS_2XX"
    }
  }

  monitored_resource {
    type   = "uptime_url"
    labels = {
      project_id = var.project_id
      host       = replace(replace(var.app_url, "https://", ""), "/", "")
    }
  }

  selected_regions = ["USA", "EUROPE", "ASIA_PACIFIC"]
}

# ── Log-Based Metrics ─────────────────────────────────────────
resource "google_logging_metric" "error_count" {
  name        = "${var.app_name}_error_count"
  description = "Count of ERROR severity log entries"
  filter      = "resource.type=\"gae_app\" severity=ERROR"
  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "INT64"
    unit        = "1"
    labels {
      key         = "severity"
      value_type  = "STRING"
      description = "Log severity"
    }
  }
  depends_on = [google_project_service.logging]
}

resource "google_logging_metric" "http_5xx" {
  name        = "${var.app_name}_http_5xx"
  description = "Count of HTTP 5xx responses"
  filter      = "resource.type=\"gae_app\" httpRequest.status>=500"
  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "INT64"
    unit        = "1"
  }
  depends_on = [google_project_service.logging]
}

# ── Alert Policy: High CPU ────────────────────────────────────
resource "google_monitoring_alert_policy" "high_cpu" {
  display_name = "${var.app_name} — High CPU Utilization"
  combiner     = "OR"
  enabled      = true
  severity     = "WARNING"

  conditions {
    display_name = "CPU > 80% for 5 minutes"
    condition_threshold {
      filter          = "resource.type = \"gce_instance\" AND metric.type = \"compute.googleapis.com/instance/cpu/utilization\""
      duration        = "300s"
      comparison      = "COMPARISON_GT"
      threshold_value = 0.80
      aggregations {
        alignment_period     = "300s"
        per_series_aligner   = "ALIGN_MEAN"
        cross_series_reducer = "REDUCE_MEAN"
        group_by_fields      = ["resource.labels.instance_id"]
      }
      trigger { count = 1 }
    }
  }

  notification_channels = [google_monitoring_notification_channel.email.id]

  documentation {
    content   = "CPU utilization > 80% for 5 min. Check for runaway processes or scale up."
    mime_type = "text/markdown"
  }

  alert_strategy {
    auto_close = "1800s"
    notification_rate_limit { period = "300s" }
  }
}

# ── Alert Policy: High Memory ─────────────────────────────────
resource "google_monitoring_alert_policy" "high_memory" {
  display_name = "${var.app_name} — High Memory Usage"
  combiner     = "OR"
  enabled      = true
  severity     = "WARNING"

  conditions {
    display_name = "Memory > 85% for 5 minutes"
    condition_threshold {
      filter          = "resource.type = \"gce_instance\" AND metric.type = \"agent.googleapis.com/memory/percent_used\""
      duration        = "300s"
      comparison      = "COMPARISON_GT"
      threshold_value = 85
      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_MEAN"
      }
      trigger { count = 1 }
    }
  }

  notification_channels = [google_monitoring_notification_channel.email.id]

  documentation {
    content   = "Memory usage > 85%. Investigate memory leaks or increase instance memory."
    mime_type = "text/markdown"
  }
}

# ── Alert Policy: 5xx Errors ──────────────────────────────────
resource "google_monitoring_alert_policy" "http_5xx" {
  display_name = "${var.app_name} — HTTP 5xx Error Rate"
  combiner     = "OR"
  enabled      = true
  severity     = "ERROR"

  conditions {
    display_name = "5xx error rate > 1%"
    condition_threshold {
      filter          = "resource.type = \"gae_app\" AND metric.type = \"appengine.googleapis.com/http/server/response_count\" AND metric.labels.response_code >= \"500\""
      duration        = "300s"
      comparison      = "COMPARISON_GT"
      threshold_value = 0.01
      aggregations {
        alignment_period     = "300s"
        per_series_aligner   = "ALIGN_RATE"
        cross_series_reducer = "REDUCE_SUM"
      }
    }
  }

  notification_channels = [google_monitoring_notification_channel.email.id]

  documentation {
    content   = "5xx error rate > 1%. Check application logs immediately."
    mime_type = "text/markdown"
  }
}

# ── Alert Policy: High Latency ────────────────────────────────
resource "google_monitoring_alert_policy" "high_latency" {
  display_name = "${var.app_name} — High Request Latency"
  combiner     = "OR"
  enabled      = true
  severity     = "WARNING"

  conditions {
    display_name = "p95 latency > 2000ms"
    condition_threshold {
      filter          = "resource.type = \"gae_app\" AND metric.type = \"appengine.googleapis.com/http/server/response_latencies\""
      duration        = "300s"
      comparison      = "COMPARISON_GT"
      threshold_value = 2000
      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_PERCENTILE_95"
      }
    }
  }

  notification_channels = [google_monitoring_notification_channel.email.id]
}

# ── Alert Policy: Disk Usage ──────────────────────────────────
resource "google_monitoring_alert_policy" "disk_critical" {
  display_name = "${var.app_name} — Disk Usage Critical"
  combiner     = "OR"
  enabled      = true
  severity     = "CRITICAL"

  conditions {
    display_name = "Disk > 90%"
    condition_threshold {
      filter          = "resource.type = \"gce_instance\" AND metric.type = \"agent.googleapis.com/disk/percent_used\""
      duration        = "60s"
      comparison      = "COMPARISON_GT"
      threshold_value = 90
      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_MEAN"
      }
    }
  }

  notification_channels = [google_monitoring_notification_channel.email.id]
}

# ── Alert Policy: Uptime Failure ──────────────────────────────
resource "google_monitoring_alert_policy" "uptime_failure" {
  display_name = "${var.app_name} — Uptime Check Failed"
  combiner     = "OR"
  enabled      = true
  severity     = "CRITICAL"

  conditions {
    display_name = "Health check failing"
    condition_threshold {
      filter = "resource.type = \"uptime_url\" AND metric.type = \"monitoring.googleapis.com/uptime_check/check_passed\" AND metric.labels.check_id = \"${google_monitoring_uptime_check_config.health.uptime_check_id}\""
      duration        = "60s"
      comparison      = "COMPARISON_LT"
      threshold_value = 1
      aggregations {
        alignment_period     = "300s"
        per_series_aligner   = "ALIGN_FRACTION_TRUE"
        cross_series_reducer = "REDUCE_SUM"
        group_by_fields      = ["resource.labels.host"]
      }
    }
  }

  notification_channels = [google_monitoring_notification_channel.email.id]
}

# ── Alert Policy: Cloud SQL Connections ───────────────────────
resource "google_monitoring_alert_policy" "sql_connections" {
  display_name = "${var.app_name} — SQL Connection Saturation"
  combiner     = "OR"
  enabled      = true
  severity     = "WARNING"

  conditions {
    display_name = "DB connections > 90"
    condition_threshold {
      filter          = "resource.type = \"cloudsql_database\" AND metric.type = \"cloudsql.googleapis.com/database/postgresql/num_backends\""
      duration        = "300s"
      comparison      = "COMPARISON_GT"
      threshold_value = 90
      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_MEAN"
      }
    }
  }

  notification_channels = [google_monitoring_notification_channel.email.id]
}

# ── Dashboard ─────────────────────────────────────────────────
resource "google_monitoring_dashboard" "app_dashboard" {
  dashboard_json = jsonencode({
    displayName = "${var.app_name} — Application Metrics"
    mosaicLayout = {
      columns = 12
      tiles = [
        # CPU
        {
          width = 6, height = 4, xPos = 0, yPos = 0
          widget = {
            title = "CPU Utilization"
            xyChart = {
              dataSets = [{
                timeSeriesQuery = {
                  timeSeriesFilter = {
                    filter = "metric.type=\"compute.googleapis.com/instance/cpu/utilization\" resource.type=\"gce_instance\""
                    aggregation = { alignmentPeriod = "60s", perSeriesAligner = "ALIGN_MEAN" }
                  }
                }
                plotType = "LINE"
              }]
              yAxis = { label = "Utilization", scale = "LINEAR" }
            }
          }
        },
        # Memory
        {
          width = 6, height = 4, xPos = 6, yPos = 0
          widget = {
            title = "Memory Usage %"
            xyChart = {
              dataSets = [{
                timeSeriesQuery = {
                  timeSeriesFilter = {
                    filter = "metric.type=\"agent.googleapis.com/memory/percent_used\" resource.type=\"gce_instance\""
                    aggregation = { alignmentPeriod = "60s", perSeriesAligner = "ALIGN_MEAN" }
                  }
                }
                plotType = "LINE"
              }]
            }
          }
        },
        # HTTP Request Count
        {
          width = 6, height = 4, xPos = 0, yPos = 4
          widget = {
            title = "HTTP Request Rate"
            xyChart = {
              dataSets = [{
                timeSeriesQuery = {
                  timeSeriesFilter = {
                    filter = "metric.type=\"appengine.googleapis.com/http/server/request_count\" resource.type=\"gae_app\""
                    aggregation = { alignmentPeriod = "60s", perSeriesAligner = "ALIGN_RATE" }
                  }
                }
                plotType = "STACKED_BAR"
              }]
            }
          }
        },
        # Latency
        {
          width = 6, height = 4, xPos = 6, yPos = 4
          widget = {
            title = "Request Latency p50/p95/p99"
            xyChart = {
              dataSets = [
                {
                  timeSeriesQuery = {
                    timeSeriesFilter = {
                      filter = "metric.type=\"appengine.googleapis.com/http/server/response_latencies\" resource.type=\"gae_app\""
                      aggregation = { alignmentPeriod = "60s", perSeriesAligner = "ALIGN_PERCENTILE_50" }
                    }
                  }
                  plotType = "LINE", legendTemplate = "p50"
                },
                {
                  timeSeriesQuery = {
                    timeSeriesFilter = {
                      filter = "metric.type=\"appengine.googleapis.com/http/server/response_latencies\" resource.type=\"gae_app\""
                      aggregation = { alignmentPeriod = "60s", perSeriesAligner = "ALIGN_PERCENTILE_95" }
                    }
                  }
                  plotType = "LINE", legendTemplate = "p95"
                }
              ]
            }
          }
        },
        # Error count
        {
          width = 4, height = 4, xPos = 0, yPos = 8
          widget = {
            title = "5xx Error Count"
            xyChart = {
              dataSets = [{
                timeSeriesQuery = {
                  timeSeriesFilter = {
                    filter = "metric.type=\"logging.googleapis.com/user/${var.app_name}_http_5xx\""
                    aggregation = { alignmentPeriod = "60s", perSeriesAligner = "ALIGN_RATE" }
                  }
                }
                plotType = "STACKED_AREA"
              }]
            }
          }
        },
        # Uptime
        {
          width = 4, height = 4, xPos = 4, yPos = 8
          widget = {
            title = "Uptime Check Passed"
            xyChart = {
              dataSets = [{
                timeSeriesQuery = {
                  timeSeriesFilter = {
                    filter = "metric.type=\"monitoring.googleapis.com/uptime_check/check_passed\" resource.type=\"uptime_url\""
                    aggregation = { alignmentPeriod = "60s", perSeriesAligner = "ALIGN_FRACTION_TRUE" }
                  }
                }
                plotType = "LINE"
              }]
            }
          }
        },
        # Disk
        {
          width = 4, height = 4, xPos = 8, yPos = 8
          widget = {
            title = "Disk Usage %"
            xyChart = {
              dataSets = [{
                timeSeriesQuery = {
                  timeSeriesFilter = {
                    filter = "metric.type=\"agent.googleapis.com/disk/percent_used\" resource.type=\"gce_instance\""
                    aggregation = { alignmentPeriod = "60s", perSeriesAligner = "ALIGN_MEAN" }
                  }
                }
                plotType = "LINE"
              }]
            }
          }
        }
      ]
    }
  })
}

# ── Outputs ───────────────────────────────────────────────────
output "notification_channel_id" { value = google_monitoring_notification_channel.email.id }
output "uptime_check_id"         { value = google_monitoring_uptime_check_config.health.uptime_check_id }
output "dashboard_id"            { value = google_monitoring_dashboard.app_dashboard.id }
output "console_url" {
  value = "https://console.cloud.google.com/monitoring?project=${var.project_id}"
}
