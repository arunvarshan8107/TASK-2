# Google Cloud Monitoring — Setup Package

Complete monitoring stack for a cloud-based application: 7 alert policies,
uptime checks across 3 global regions, log-based metrics, and a dashboard
with 8 metric charts.

---

## 📁 Package Contents

```
gcp-monitoring/
├── scripts/
│   └── setup_monitoring.sh   ← Bash one-shot setup
├── configs/
│   └── main.tf               ← Terraform IaC (recommended)
└── README.md
```

---

## ⚡ Quick Start — Bash

```bash
gcloud auth login
gcloud auth application-default login

bash scripts/setup_monitoring.sh my-project-id my-app alerts@example.com us-central1
```

---

## 🏗️ Terraform (recommended)

```bash
cd configs/
cp terraform.tfvars.example terraform.tfvars  # fill in your values

terraform init
terraform plan
terraform apply
```

---

## 🔔 Alert Policies (7)

| Policy | Condition | Severity | Notification |
|--------|-----------|----------|-------------|
| High CPU utilization | > 80% for 5 min | WARNING | Email |
| High memory usage | > 85% for 5 min | WARNING | Email |
| HTTP 5xx error rate | > 1% for 5 min | ERROR | Email |
| High request latency | p95 > 2s for 5 min | WARNING | Email |
| Disk usage critical | > 90% for 1 min | CRITICAL | Email |
| Uptime check failure | Health endpoint down | CRITICAL | Email |
| SQL connection saturation | > 90 connections | WARNING | Email |

---

## 📊 Dashboard Panels (8)

| Panel | Metric | Chart type |
|-------|--------|-----------|
| CPU utilization | compute.googleapis.com/instance/cpu/utilization | Line |
| Memory usage % | agent.googleapis.com/memory/percent_used | Line |
| HTTP request rate | appengine.googleapis.com/http/server/request_count | Bar |
| Request latency p50/p95 | appengine.googleapis.com/http/server/response_latencies | Multi-line |
| 5xx error count | logging (log-based metric) | Area |
| Uptime check status | monitoring.googleapis.com/uptime_check/check_passed | Line |
| Disk usage % | agent.googleapis.com/disk/percent_used | Line |
| DB connections | cloudsql.googleapis.com/database/postgresql/num_backends | Line |

---

## 🌐 Uptime Checks

Health checks are run every 60 seconds from 3 global regions:
- USA
- Europe
- Asia-Pacific

Endpoint: `GET /health` — expects HTTP 2xx + body containing `ok`

---

## 📝 Log-Based Metrics

| Metric name | Log filter | Used in |
|------------|------------|---------|
| `{app}_error_count` | `severity=ERROR` | Error rate alerting |
| `{app}_http_5xx` | `httpRequest.status>=500` | 5xx dashboard panel |

---

## 🔑 Notification Channels

Email alerts are sent to the configured address for all CRITICAL and WARNING policies.

To add PagerDuty, Slack, or SMS channels after setup:

```bash
# Slack
gcloud alpha monitoring channels create \
  --display-name="Slack #alerts" \
  --type=slack \
  --channel-labels="channel_name=#alerts,auth_token=YOUR_TOKEN"

# PagerDuty
gcloud alpha monitoring channels create \
  --display-name="PagerDuty" \
  --type=pagerduty \
  --channel-labels="service_key=YOUR_KEY"
```

---

## 🛠️ Useful Commands

```bash
# List all alert policies
gcloud alpha monitoring policies list

# List notification channels
gcloud alpha monitoring channels list

# List uptime checks
gcloud alpha monitoring uptime list

# View dashboard in console
open https://console.cloud.google.com/monitoring?project=YOUR_PROJECT

# Silence an alert (snooze 1h)
gcloud alpha monitoring snoozes create \
  --display-name="Planned maintenance" \
  --interval-start-time="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  --interval-end-time="$(date -u -d '+1 hour' +%Y-%m-%dT%H:%M:%SZ)"
```

---

## 🔒 Security Notes

- Alert email addresses are stored as notification channel labels — treat them as PII.
- Terraform state contains notification channel IDs — store state in GCS with encryption.
- Use Workload Identity for services sending custom metrics instead of service account keys.
